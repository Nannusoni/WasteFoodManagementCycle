<!-- Start Footer-->
  <footer class="container-fluid bg-dark text-white mt-5" style="border-top: 3px solid #DC3545;">
    <div class="container">
      <!-- Start Footer Container -->
      <div class="row py-3">
        <!-- Start Footer Row -->
        <div class="col-md-6">
          <!-- Start Footer 1st Column -->
          <span class="pr-2">Follow Us: </span>
          <a href="https://www.facebook.com/deepakpoint11" target="_blank" class="pr-2 fi-color"><i class="fab fa-facebook-f"style='font-size: 24px'></i></a>
          <a href="https://twitter.com/deepaksoni9517" target="_blank" class="pr-2 fi-color"><i class="fab fa-twitter"style='font-size: 24px'></i></a>
          <a href="#" target="_blank" class="pr-2 fi-color"><i class="fab fa-youtube"style='font-size: 24px'></i></a>
          <a href="#" target="_blank" class="pr-2 fi-color"><i class="fab fa-google-plus-g" style='font-size: 24px'></i></a>
          <a href="https://www.instagram.com/deepaksoni9517/" target="_blank" class="pr-2 fi-color"><i class='fab fa-instagram' style='font-size:24px'></i></a>
        </div> <!-- End Footer 1st Column -->

        <div class="col-md-6 text-right">
          <!-- Start Footer 2nd Column -->
          <div class="credit">Made with<span style="color:tomato">❤</span> by 
    <a href="https://www.instagram.com/deepaksoni9517/"</a><br>Nandeshwar Soni</a> &
    <a href="https://www.instagram.com/official_abhishek__24/"</a> Abhishek Yadav</br>
    </div>
         <!-- <small class="ml-2"><a href="Admin/login.php">Admin Login</a></small>-->
        </div> <!-- End Footer 2nd Column -->
      </div> <!-- End Footer Row -->
    </div> <!-- End Footer Container -->
  </footer> <!-- End Footer -->
<!-- Start Footer-->
  <footer class="container-fluid bg-dark text-white mt-5" style="border-top: 3px solid #DC3545;">
    <div class="container">
      <!-- Start Footer Container -->
      <div class="row py-3">
        <!-- Start Footer Row -->
        <div class="col-md-6">
          <!-- Start Footer 1st Column -->
          <span class="pr-2">Follow Us: </span>
          <a href="https://www.facebook.com/deepakpoint11" target="_blank" class="pr-2 fi-color"><i class="fab fa-facebook-f"style='font-size: 24px'></i></a>
          <a href="https://twitter.com/deepaksoni9517" target="_blank" class="pr-2 fi-color"><i class="fab fa-twitter"style='font-size: 24px'></i></a>
          <a href="#" target="_blank" class="pr-2 fi-color"><i class="fab fa-youtube"style='font-size: 24px'></i></a>
          <a href="#" target="_blank" class="pr-2 fi-color"><i class="fab fa-google-plus-g" style='font-size: 24px'></i></a>
          <a href="https://www.instagram.com/deepaksoni9517/" target="_blank" class="pr-2 fi-color"><i class='fab fa-instagram' style='font-size:24px'></i></a>
        </div> <!-- End Footer 1st Column -->

        <div class="col-md-6 text-right">
          <!-- Start Footer 2nd Column -->
          <div class="credit">Made with<span style="color:tomato">❤</span> by 
    <a href="https://www.instagram.com/deepaksoni9517/"</a><br>Nandeshwar Soni</a> &
    <a href="https://www.instagram.com/official_abhishek__24/"</a> Abhishek Yadav</br>
    </div>
         <!-- <small class="ml-2"><a href="Admin/login.php">Admin Login</a></small>-->
        </div> <!-- End Footer 2nd Column -->
      </div> <!-- End Footer Row -->
    </div> <!-- End Footer Container -->
  </footer> <!-- End Footer -->
