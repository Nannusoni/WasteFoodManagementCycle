

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>About Us</title>
        <script async custom-element="amp-ad" src="https://cdn.ampproject.org/v0/amp-ad-0.1.js"></script>
        <link rel="icon" type="image/x-icon" href="images/fav.jpg">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/styl1.css">
        <script src="https://kit.fontawesome.com/dbed6b6114.js" crossorigin="anonymous"></script>
    </head>
	
    <body>
    <amp-ad width="100vw" height="320"
     type="adsense"
     data-ad-client="ca-pub-8522103950045705"
     data-ad-slot="9274838024"
     data-auto-format="rspv"
     data-full-width="">
  <div overflow=""></div>
</amp-ad>
        <section>
            <div class = "image">
               <img src="images\Aboutuslogo.jpg">
            </div>

<div class = "content">
<h2>About Us</h2>
<span><!-- Line here --></span>
<h3>Hello Dear Visitor,
Our Name is Nandeshwar Soni & Abhishek Yadav. We have made together this project "Waste Food Management Cycle" We are living in Mumbai.pursuing Bscit Final Year
<br><br>Author Details:<br>
We are creating Blog post related to th Computer Hardware, Networking and Software, Software Download, Hardware and Networking Notes. 
Technology, Mobile App, Online Earning, Social Network Tips and Tricks, YouTube Tips, Online Shopping, Affiliate Marketing, create new account, make money YouTube, website Creation, blogging tips and tricks, online banking, YouTube videos creation, etc 
We will share on our facebook page and also share on Telegram. 
Our Mission To Create This web-based application to collecting the leftover food from hotels & restaurants to distribute among those in need. 
NGOs that are helping poor communities to battle against starvation & malnutrition can raise a request for food supply from restaurants through this application.
Once the request is accepted, the NGOs can collect the food from the restaurants for its distribution. 
In this way this Web-based food waste management system will help restaurants to reduce food waste and will help in feeding the poor and needy people.
<amp-ad width="100vw" height="320"
     type="adsense"
     data-ad-client="ca-pub-8522103950045705"
     data-ad-slot="9274838024"
     data-auto-format="rspv"
     data-full-width="">
  <div overflow=""></div>
</amp-ad>
<br><br>Scope of the project : <br>
•	Benefits will be both the restaurant (reducing food wastage), and the needy<br> 
•	Keep track of wastage food for restaurant<br>
•	User can play role in saving food wastage and help the needy.<br>
•   Reduce Food Waste</h3><br><br>

<h4>Any question :- 
if you have any querie's and suggestion you can contact us to on in commentsection,Social Network, email.</h4>
<p>Contact us on Social Network</p>
                <ul class = "icons">
                    <li>
                        <i class = "fa fa-facebook"></i>
						<a href = "https://www.facebook.com/deepakpoint11">Facebook</a>
                    </li>
                    <li>
                        <i class = "fa fa-telegram"></i>
						<a href = "https://twitter.com/deepaksoni9517">Telegram</a>
                    </li>
                    <li>
                        <i class = "fa fa-instagram"></i>
						<a href = "https://www.instagram.com/deepaksoni9517/">Instagram</a>
                    </li>
                    <li>
                        <i class = "fa fa-address-card"></i>
						<a href = "#">Contact Us</a>
                    </li>
                </ul>
				<div class="text-center"><a class="btn btn-info mt-3 shadow-sm font-weight-bold" href="index.php">Back
            to Home</a></div>
            </div>
        </section>
        <amp-ad width="100vw" height="320"
     type="adsense"
     data-ad-client="ca-pub-8522103950045705"
     data-ad-slot="9274838024"
     data-auto-format="rspv"
     data-full-width="">
  <div overflow=""></div>
</amp-ad>
        <div class="credit">Made with<span style="color:tomato">❤</span> by 
		<a href="https://www.instagram.com/deepaksoni9517/"</a><br>Nandeshwar Soni</a>
		<a href="https://www.instagram.com/official_abhishek__24/"</a> Abhishek Yadav</br>
		</div>
		
    </body>
</html>
